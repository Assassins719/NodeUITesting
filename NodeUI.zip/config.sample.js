module.exports = {
    Api: {
        Endpoint: "",
        Key: "",
        Company: "",
        Customer: "",
        Invoice: "",
		Amount: 5,
        Currency: 'USD',
        CustomerName: '',
        DisposableInvoiceId: "test_temp_123"
    },
    Ui: {
        Endpoint: "",
        Logins: {
            InstanceAdmin: {
                Username: "",
                Password: ""
            },
            Customer: {
                Username: "",
                Password: ""
            }
        }
    }
};