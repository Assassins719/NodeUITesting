var webdriverio = require('webdriverio');
var browser = webdriverio.remote().init();