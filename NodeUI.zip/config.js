module.exports = {
    Api: {
        Endpoint: "http://aps-click-to-pay.us-east-2.elasticbeanstalk.com/api/",
        Key: "test_XweF4yRa5jxrwW17zDHNT8C8YgAt1l",
        Company: "aw_sc",
        Customer: "jsmith1980",
        Invoice: "test_4818923",
        Amount:5,
        Date_Date:"2017-09-13",
        Currency: "USD",
        CustomerName: "John Smith",
        CustomerEmail: "john.smith@example.com",
        OrderDescription: "My Order",
        PoNumber: "12345",
        OrderId: "12345",
        DisposableInvoiceId: "test_temp_4818923",
        Shipping: {
            line1: "123 Some Lane",
            line2: "",
            city: "Greenville",
            country: "USA",
            firstName: "John",
            lastName: "Smith",
            postalCode: "12345",
            state: "AK"
        },
        //Error codes
        CompanyWrong:'wrong',
        CustommerWrong : 'wrong',
        AmountWrong: 99999999,
        InvocieWorng:"abc123",
        Type_Company:1,
        Type_InvoiceUpdate:2,
        Type_Amount:3,
        Type_InvoiceCreate:4
    },
    Ui: {
        Endpoint: "http://c2pwebapp-dev.us-east-2.elasticbeanstalk.com/",
        C2PCode: "B7AKyq1VJDXrAm292DcznOaD2R_QQEW8"
    }
};