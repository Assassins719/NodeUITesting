Overview
========

Getting Started
===============
Selenium
--------
Set up your standalone Selenium server as well as any drivers.

Other setup
-----------
**Create wdio.conf.js**.  Copy the provided wdio.conf.sample.js to use as a starting point, replacing the URL endpoint.

Quick Command Reference
-----------------------
The following is a quick command reference to get started.

    npm install
    

